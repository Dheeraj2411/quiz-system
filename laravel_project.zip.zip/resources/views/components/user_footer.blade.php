 <footer class="bg-gray-800 text-white py-3">
     <div class="container mx-auto px-4 text-center">
         <p class="text-sm md:text-base">&copy; 2025 All Rights Reserved</p>
         <div class="mt-2 flex flex-col sm:flex-row sm:justify-center space-y-2 sm:space-y-0 sm:space-x-7">
             <a href="" class="hover:text-gray-300 transition-colors">Home</a>
             <a href="" class="hover:text-gray-300 transition-colors">About</a>
             <a href="" class="hover:text-gray-300 transition-colors">Contact</a>
         </div>
     </div>
 </footer>