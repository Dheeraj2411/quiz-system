<div>
    Hi
    <p>This mail from Quiz-System</p>
    <p>Please click on link to reset password</p>
    <a href="{{Str::slug($link)}}">Click Here</a>
</div>