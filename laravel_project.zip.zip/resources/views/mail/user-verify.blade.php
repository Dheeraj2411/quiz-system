<div>
    <div>
        Thank you for signing up! Please verify your email address to complete your registration Click the button below
        to verify your email:
    </div>
    <a href="{{Str::slug($link)}}">Verify Email</a>
</div>